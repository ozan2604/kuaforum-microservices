﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appointment.Persistence.Contexts
{
    public class AppointmentServiceDbContext : DbContext
    {
    }
}
